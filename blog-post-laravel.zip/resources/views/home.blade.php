@extends('layouts.main')
@section('container')
    <h1>Halaman Home</h1>
@endsection

    
